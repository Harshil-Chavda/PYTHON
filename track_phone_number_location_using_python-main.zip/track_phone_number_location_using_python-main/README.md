# track_phone_number_location_using_python
This code imports the necessary libraries/modules, including phonenumbers, which is used to parse phone numbers, geocoder, which is used to determine the location of a phone number, and folium, which is used to create maps. It also assigns a value to the variable Key.
